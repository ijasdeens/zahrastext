# simple-pos-ui
simple point of sale UI using bootstrap
<img src="https://i.imgur.com/GBgKghJ.png">
